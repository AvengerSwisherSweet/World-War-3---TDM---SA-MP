<?php
/**
 * Shoutbox Plugin for MyBB
 * Copyright � 2008 MyBB Mods
 *
 * By: Musicalmidget
 * Website: http://mods.mybboard.net/
 * Version: 2.2.0
 */

// Disallow direct access to this file for security reasons
if(!defined("IN_MYBB"))
{
	die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
}

$plugins->add_hook('global_start', 'shoutbox_get_data'); // in dev
$plugins->add_hook('global_start', 'shoutbox_link');
$plugins->add_hook('global_start', 'shoutbox_refresh');
$plugins->add_hook('index_start', 'shoutbox_main');
$plugins->add_hook('admin_load', 'shoutbox_admin');
$plugins->add_hook('admin_tools_menu', 'shoutbox_admin_tools_menu');
$plugins->add_hook('admin_tools_permissions', 'shoutbox_admin_tools_permissions');
$plugins->add_hook('admin_tools_action_handler', 'shoutbox_admin_tools_action_handler');
$plugins->add_hook('admin_page_output_footer', 'shoutbox_settings_peeker');
$plugins->add_hook('admin_user_groups_edit', 'shoutbox_admin_groups_edit');
$plugins->add_hook('admin_user_groups_edit_commit', 'shoutbox_admin_groups_edit_commit');

function shoutbox_info()
{
	global $lang;
	$lang->load('shoutbox');

	// NOTE: During beta testing this plugin carried the GUID 1cbde2fe7e9b65292ca4ff7c91e0cccc
	return array(
		'name'			=> $lang->shoutbox,
		'description'	=> $lang->shoutbox_description,
		'website'		=> 'http://mods.mybboard.net/',
		'author'		=> 'Musicalmidget',
		'authorsite'	=> 'http://musicalmidget.com/',
		'version'		=> '2.2.0',
		'guid'			=> '0ea59e88a91be72e720bae9551b2dba6',
		'combatibility'	=> '14*'
	);
}

function shoutbox_install()
{
	global $cache, $db, $lang;
	$lang->load('shoutbox');

	$db->write_query("
		CREATE TABLE `".TABLE_PREFIX."shouts` (
			`sid` int(10) unsigned NOT NULL auto_increment,
			`uid` int(10) unsigned NOT NULL default '0',
			`message` text NOT NULL,
			`dateline` bigint(30) NOT NULL default '0',
			`ipaddress` varchar(30) NOT NULL default '',
			PRIMARY KEY (`sid`)
		) TYPE=MyISAM
	");

	$db->write_query("INSERT INTO `".TABLE_PREFIX."settinggroups` VALUES (NULL, 'shoutbox', '{$lang->setting_group_shoutbox}', '{$lang->setting_group_shoutbox_desc}', 25, '0');");
	$gid = $db->insert_id();
	
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_shouts_per_page', '{$lang->setting_sb_shouts_per_page}', '{$lang->setting_sb_shouts_per_page_desc}', 'text', '25', 1, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_refresh_time', '{$lang->setting_sb_refresh_time}', '{$lang->setting_sb_refresh_time_desc}', 'text', '60', 2, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_max_consec_shouts', '{$lang->setting_sb_max_consec_shouts}', '{$lang->setting_sb_max_consec_shouts_desc}', 'text', '5', 3, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_max_length', '{$lang->setting_sb_max_length}', '{$lang->setting_sb_max_length_desc}', 'text', '150', 4, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_min_length', '{$lang->setting_sb_min_length}', '{$lang->setting_sb_min_length_desc}', 'text', '2', 5, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_allow_html', '{$lang->setting_sb_allow_html}', '{$lang->setting_sb_allow_html_desc}', 'yesno', 0, 6, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_allow_mycode', '{$lang->setting_sb_allow_mycode}', '{$lang->setting_sb_allow_mycode_desc}', 'yesno', 1, 7, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_allow_smilies', '{$lang->setting_sb_allow_smilies}', '{$lang->setting_sb_allow_smilies_desc}', 'yesno', 1, 8, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_allow_imgcode', '{$lang->setting_sb_allow_imgcode}', '{$lang->setting_sb_allow_imgcode_desc}', 'yesno', 0, 9, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_display_mode', '{$lang->setting_sb_display_mode}', '{$lang->setting_sb_display_mode_desc}', 'radio\nwindow=Window Only\nindex=Index Only\nboth=Both Window and Index', 'window', 10, {$gid}, 0)");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_index_shouts', '{$lang->setting_sb_index_shouts}', '{$lang->setting_sb_index_shouts_desc}', 'text', '5', 11, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_sort_order', '{$lang->setting_sb_sort_order}', '{$lang->setting_sb_sort_order_desc}', 'radio\nasc=Ascending\ndsc=Descending', 'asc', 12, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_friendly_redirects', '{$lang->setting_sb_friendly_redirects}', '{$lang->setting_sb_friendly_redirects_desc}', 'yesno', 1, 13, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_width', '{$lang->setting_sb_width}', '{$lang->setting_sb_width_desc}', 'text', '400', 14, {$gid}, 0);");
	$db->write_query("INSERT INTO `".TABLE_PREFIX."settings` VALUES (NULL, 'sb_height', '{$lang->setting_sb_height}', '{$lang->setting_sb_height_desc}', 'text', '350', 15, {$gid}, 0);");
	
	rebuildsettings();
	
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` ADD `can_view_shoutbox` int(1) unsigned NOT NULL default '1'");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` ADD `can_post_shouts` int(1) unsigned NOT NULL default '1'");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` ADD `can_edit_own_shouts` int(1) unsigned NOT NULL default '1'");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` ADD `can_delete_own_shouts` int(1) unsigned NOT NULL default '1'");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` ADD `can_moderate_shouts` int(1) unsigned NOT NULL default '0'");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` ADD `can_bypass_limit` int(1) unsigned NOT NULL default '0'");
	
	$updated_perms = array(
		'can_view_shoutbox'		=> 0,
		'can_post_shouts'		=> 0,
		'can_edit_own_shouts'	=> 0,
		'can_delete_own_shouts'	=> 0,
	);
	
	$db->update_query('usergroups', $updated_perms, "gid IN (1,7)");
	
	$updated_perms = array(
		'can_moderate_shouts'	=> 1,
		'can_bypass_limit'		=> 1,
	);
	
	$db->update_query('usergroups', $updated_perms, "gid IN (3,4)");
	
	$db->write_query("UPDATE `".TABLE_PREFIX."usergroups` SET `can_moderate_shouts`='1' WHERE `gid` IN (3,4)");
	
	$cache->update_usergroups();
}

function shoutbox_is_installed()
{
	global $db;

	if($db->table_exists('shouts'))
	{
		return true;
	}

	return false;
}

function shoutbox_uninstall()
{
	global $cache, $db;

	$db->drop_table('shouts');
	$db->delete_query('settinggroups', "name='shoutbox'");
	
	$delete_settings = array(
		'sb_shouts_per_page',
		'sb_refresh_time',
		'sb_max_consec_shouts',
		'sb_max_length',
		'sb_min_length',
		'sb_allow_html',
		'sb_allow_mycode',
		'sb_allow_smilies',
		'sb_allow_imgcode',
		'sb_display_mode',
		'sb_index_shouts',
		'sb_sort_order',
		'sb_friendly_redirects',
		'sb_width',
		'sb_height'
	);
	
	foreach($delete_settings as $setting)
	{
		$db->delete_query('settings', "name='{$setting}'");
	}

	rebuildsettings();

	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` DROP `can_view_shoutbox`");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` DROP `can_post_shouts`");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` DROP `can_edit_own_shouts`");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` DROP `can_delete_own_shouts`");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` DROP `can_moderate_shouts`");
	$db->write_query("ALTER TABLE `".TABLE_PREFIX."usergroups` DROP `can_bypass_limit`");
	
	$cache->update_usergroups();
}

function shoutbox_activate()
{
	global $db;
	
	$new_templates = array();
	
	$new_templates['shoutbox'] = '<html>
<head>
	<title>{$mybb->settings[\'bbname\']} - {$lang->shoutbox}</title>
	{$headerinclude}
</head>
<body>
<table border="0" cellspacing="{$theme[\'borderwidth\']}" cellpadding="{$theme[\'tablespace\']}" class="tborder">
<tr>
<td class="thead"><strong>{$lang->shoutbox}</strong></td>
</tr>
{$multipage_top}
{$shouts}
{$multipage_bottom}
</table>
<br />
<table border="0" cellspacing="{$theme[\'borderwidth\']}" cellpadding="{$theme[\'tablespace\']}" class="tborder">
<tr>
<td class="trow1" align="center">
{$add_shout}
{$toggle_refresh_link}
<a name="shoutbox"></a>
</td>
</tr>
</table>
</body>
</html>';

	$new_templates['shoutbox_add_shout'] = '<form method="post" action="index.php?go_to=shoutbox&amp;view_mode={$view_mode}&amp;action=add">
<input type="text" name="message" size="40" maxlength="{$mybb->settings[\'sb_max_length\']}" />
&nbsp;<input type="submit" name="submit" value="{$lang->shout_refresh}" /><br />
</form>';
	
	$new_templates['shoutbox_delete_shout'] = '<html>
<head>
	<title>{$mybb->settings[\'bbname\']} - {$lang->shoutbox}</title>
	{$headerinclude}
</head>
<body>
<table border="0" cellspacing="{$theme[\'borderwidth\']}" cellpadding="{$theme[\'tablespace\']}" class="tborder">
<tr>
<td class="thead"><strong>{$lang->delete_shout}</strong></td>
</tr>
<tr>
<td class="trow1" align="center">
{$lang->confirm_shout_delete}<br /><br />
<form method="post" action="index.php?go_to=shoutbox&amp;view_mode={$view_mode}&amp;action=delete">
<input type="hidden" name="sid" value="{$shout[\'sid\']}" />
&nbsp;<input type="submit" name="deletesubmit" value="{$lang->yes}" />
&nbsp;<input type="submit" name="no" value="{$lang->no}" />
</form>
</td>
</tr>
</table>
</body>
</html>';
	
	$new_templates['shoutbox_edit_shout'] = '<html>
<head>
	<title>{$mybb->settings[\'bbname\']} - {$lang->shoutbox}</title>
	{$headerinclude}
</head>
<body>
<table border="0" cellspacing="{$theme[\'borderwidth\']}" cellpadding="{$theme[\'tablespace\']}" class="tborder">
<tr>
<td class="thead"><strong>{$lang->edit_shout}</strong></td>
</tr>
<tr>
<td class="trow1" align="center">
<form method="post" action="index.php?go_to=shoutbox&amp;view_mode={$view_mode}&amp;action=edit">
<input type="hidden" name="sid" value="{$shout[\'sid\']}" />
<input type="text" name="message" value="{$message}" size="40" maxlength="{$mybb->settings[\'sb_max_length\']}" />
&nbsp;<input type="submit" name="submit" value="{$lang->edit_shout}" />
</form>
</td>
</tr>
</table>
</body>
</html>';
	
	$new_templates['shoutbox_error'] = '<html>
<head>
	<title>{$mybb->settings[\'bbname\']}</title>
	{$headerinclude}
</head>
<body>
<table border="0" cellspacing="{$theme[\'borderwidth\']}" cellpadding="{$theme[\'tablespace\']}" class="tborder">
<tr>
<td class="trow1">{$message}</td>
</tr>
</table>
</body>
</html>';
	
	$new_templates['shoutbox_error_no_shouts'] = '<tr>
<td class="trow1" align="center">{$lang->error_no_shouts}</td>
</tr>';
	
	$new_templates['shoutbox_index'] = '<table border="0" cellspacing="{$theme[\'borderwidth\']}" cellpadding="{$theme[\'tablespace\']}" class="tborder">
<tr>
<td class="thead"><strong>{$lang->shoutbox}</strong></td>
</tr>
{$shouts}
{$multipage_bottom}
</table>
<br />
<table border="0" cellspacing="{$theme[\'borderwidth\']}" cellpadding="{$theme[\'tablespace\']}" class="tborder" style="margin-bottom: 20px;">
<tr>
<td class="trow1" align="center">
{$add_shout}
{$toggle_refresh_link}
</td>
</tr>
</table>
<a name="shoutbox" id="shoutbox"></a>';
	
	$new_templates['shoutbox_multipage_links'] = '<tr>
<td class="{$bgcolor}" align="center">
<span class="smalltext">{$multipage_links}</span>
</td>
</tr>';
	
	$new_templates['shoutbox_shout'] = '<tr>
<td class="{$bgcolor}" align="left" title="{$shout_hover}">
<span class="smalltext">{$username} {$shout[\'message\']}{$options}</span>
</td>
</tr>';
	
	$new_templates['shoutbox_toggle_refresh_link'] = '<a href="index.php?go_to=shoutbox&amp;view_mode={$view_mode}&amp;action=toggle_refresh">{$lang->auto_refresh}</a>';
	
	foreach($new_templates as $title => $template)
	{
		$new_template = array(
			'title'		=> $db->escape_string($title),
			'template'	=> $db->escape_string($template),
			'sid'		=> '-1',
			'version'	=> '140',
			'dateline'	=> TIME_NOW
		);
		
		$db->insert_query('templates', $new_template);
	}
	
	require_once MYBB_ROOT.'inc/adminfunctions_templates.php';
	
	find_replace_templatesets('header_welcomeblock_member', '#{\$lang->welcome_open_buddy_list}</a>#', '{\$lang->welcome_open_buddy_list}</a>{\$shoutbox_link}');
	find_replace_templatesets('header_welcomeblock_guest', '#{\$lang->welcome_current_time}#', '{\$lang->welcome_current_time}{\$shoutbox_link}');
	find_replace_templatesets('headerinclude', '#{\$newpmmsg}#', "{\$newpmmsg}\n{\$sb_refresh}");
	find_replace_templatesets('index', '#{\$boardstats}#', "{\$boardstats}\n{\$shoutbox}");
	
	change_admin_permission('tools', 'shoutbox_pruning', 0);
}

function shoutbox_deactivate()
{
	global $db;
	
	$delete_templates = array(
		'shoutbox',
		'shoutbox_add_shout',
		'shoutbox_delete_shout',
		'shoutbox_edit_shout',
		'shoutbox_error',
		'shoutbox_error_no_shouts',
		'shoutbox_index',
		'shoutbox_multipage_links',
		'shoutbox_shout',
		'shoutbox_toggle_refresh_link'
	);
	
	foreach($delete_templates as $template)
	{
		$db->delete_query('templates', "title='{$template}'");
	}
	
	require_once MYBB_ROOT.'inc/adminfunctions_templates.php';
	
	find_replace_templatesets('header_welcomeblock_member', '#{\$shoutbox_link}#', '', 0);
	find_replace_templatesets('header_welcomeblock_guest', '#{\$shoutbox_link}#', '', 0);
	find_replace_templatesets('headerinclude', '#{\$sb_refresh}#', '', 0);
	find_replace_templatesets('index', '#{\$shoutbox}#', '', 0);
	
	change_admin_permission('tools', 'shoutbox_pruning', -1);
}

function shoutbox_link()
{
	global $lang, $mybb, $shoutbox_link;
	
	if($mybb->settings['sb_display_mode'] != 'index')
	{
		$lang->load('shoutbox');
		$shoutbox_link = " | <a href=\"#\" onclick=\"MyBB.popupWindow('{$mybb->settings['bburl']}/index.php?go_to=shoutbox&amp;view_mode=window', 'shoutbox', ".$mybb->settings['sb_width'].", ".$mybb->settings['sb_height'].");\">".$lang->shoutbox."</a>";
	}
}

function shoutbox_refresh()
{
	global $mybb, $sb_refresh;
	
	$sb_refresh = '';
	if($mybb->settings['sb_refresh_time'] > 0 && $_COOKIE['sb_refresh_disable'] != '1' && strpos($_SERVER['PHP_SELF'], 'index.php'))
	{
		if($mybb->input['view_mode'] != 'window')
		{
			$sb_refresh = '<meta http-equiv="refresh" content="'.$mybb->settings['sb_refresh_time'].';URL=index.php#shoutbox" />';
		}
		else
		{
			$sb_refresh = '<meta http-equiv="refresh" content="'.$mybb->settings['sb_refresh_time'].';URL=index.php?go_to=shoutbox&amp;view_mode=window#shoutbox" />';
		}
	}
}

function shoutbox_settings_peeker()
{
	echo '<script type="text/javascript">
		new Peeker($$(".setting_sb_display_mode"), $("row_setting_sb_index_shouts"), /(index|both)/, true);
	</script>';
}

function shoutbox_admin_groups_edit()
{
	global $plugins;

	$plugins->add_hook('admin_formcontainer_end', 'shoutbox_admin_groups_edit_end');
}

function shoutbox_admin_groups_edit_commit()
{
	global $mybb, $updated_group;

	$updated_group['can_view_shoutbox'] = intval($mybb->input['can_view_shoutbox']);
	$updated_group['can_post_shouts'] = intval($mybb->input['can_post_shouts']);
	$updated_group['can_edit_own_shouts'] = intval($mybb->input['can_edit_own_shouts']);
	$updated_group['can_delete_own_shouts'] = intval($mybb->input['can_delete_own_shouts']);
	$updated_group['can_moderate_shouts'] = intval($mybb->input['can_moderate_shouts']);
	$updated_group['can_bypass_limit'] = intval($mybb->input['can_bypass_limit']);
}

function shoutbox_admin_tools_menu($sub_menu)
{
	global $lang;
	$lang->load('shoutbox');
	
	$sub_menu[] = array('id' => 'shoutbox_pruning', 'title' => $lang->shoutbox_pruning, 'link' => 'index.php?module=tools/shoutbox_pruning');
}

function shoutbox_admin_tools_action_handler($actions)
{
	$actions['shoutbox_pruning'] = array('active' => 'shoutbox_pruning', 'file' => 'shoutbox_pruning'); 
}

function shoutbox_admin_tools_permissions($admin_permissions)
{
	global $lang;
	$admin_permissions['shoutbox_pruning'] = $lang->can_prune_shoutbox;
}

function shoutbox_admin_groups_edit_end()
{
	global $mybb, $lang, $form, $form_container;

	$lang->load('shoutbox');
	
	if($form_container->_title == $lang->misc)
	{
		$shoutbox_options = array();
		$shoutbox_options[] = $form->generate_check_box('can_view_shoutbox', 1, $lang->can_view_shoutbox, array('checked' => $mybb->input['can_view_shoutbox']));
		$shoutbox_options[] = $form->generate_check_box('can_post_shouts', 1, $lang->can_post_shouts, array('checked' => $mybb->input['can_post_shouts']));
		
		if($mybb->input['gid'] != 1)
		{
			$shoutbox_options[] = $form->generate_check_box('can_edit_own_shouts', 1, $lang->can_edit_own_shouts, array('checked' => $mybb->input['can_edit_own_shouts']));
			$shoutbox_options[] = $form->generate_check_box('can_delete_own_shouts', 1, $lang->can_delete_own_shouts, array('checked' => $mybb->input['can_delete_own_shouts']));
			$shoutbox_options[] = $form->generate_check_box('can_moderate_shouts', 1, $lang->can_moderate_shouts, array('checked' => $mybb->input['can_moderate_shouts']));
		}
		
		$shoutbox_options[] = $form->generate_check_box('can_bypass_limit', 1, $lang->can_bypass_limit, array('checked' => $mybb->input['can_bypass_limit']));		

		$form_container->output_row($lang->shoutbox, '', '<div class="group_settings_bit">'.implode('</div><div class="group_settings_bit">', $shoutbox_options).'</div>');
	}
}

function shoutbox_admin()
{
	global $db, $lang, $mybb, $page, $run_module, $action_file;
	
	if($run_module == 'tools' && $action_file == 'shoutbox_pruning')
	{
		$page->add_breadcrumb_item($lang->shoutbox_pruning, 'index.php?module=tools/shoutbox_pruning');
		
		if($mybb->request_method == 'post')
		{
			$where = 'dateline < '.(TIME_NOW-(intval($mybb->input['older_than'])*86400));
			
			$db->delete_query('shouts', $where);
			$num_deleted = $db->affected_rows();
			
			log_admin_action($mybb->input['older_than'], $num_deleted);
			
			$lang->success_pruned_shouts = $lang->sprintf($lang->success_pruned_shouts, $num_deleted);
			flash_message($lang->success_pruned_shouts, 'success');
			admin_redirect("index.php?module=tools/shoutbox_pruning");
		}
		
		$page->output_header($lang->shoutbox_pruning);
		
		$sub_tabs['shoutbox_pruning'] = array(
			'title'			=> $lang->shoutbox_pruning,
			'link'			=> 'index.php?module=tools/shoutbox_pruning',
			'description'	=> $lang->shoutbox_pruning_description
		);
		
		$page->output_nav_tabs($sub_tabs, 'shoutbox_pruning');
		
		if(!$mybb->input['older_than'])
		{
			$mybb->input['older_than'] = '30';
		}
		
		$form = new Form('index.php?module=tools/shoutbox_pruning', 'post');
		$form_container = new FormContainer($lang->shoutbox_pruning);
		$form_container->output_row($lang->date_range, '', $lang->older_than.' '.$form->generate_text_box('older_than', $mybb->input['older_than'], array('id' => 'older_than', 'style' => 'width: 30px')).' '.$lang->days, 'older_than');
		$form_container->end();
		$buttons[] = $form->generate_submit_button($lang->prune_shouts);
		$form->output_submit_wrapper($buttons);
		$form->end();
		
		$page->output_footer();
		
		exit;
	}
}

function shoutbox_main()
{
	global $db, $lang, $mybb, $theme, $templates, $headerinclude, $shoutbox, $style;
	
	if($mybb->input['view_mode'] != 'window')
	{
		if($mybb->settings['sb_display_mode'] == 'window')
		{
			return;
		}
		
		$view_mode = 'index';
		$shouts_per_page = $mybb->settings['sb_index_shouts'];
		$uri = 'index.php#shoutbox';
	}
	else
	{
		$view_mode = 'window';
		$shouts_per_page = $mybb->settings['sb_shouts_per_page'];
		$uri = 'index.php?go_to=shoutbox&amp;view_mode=window';
	}
	
	if($view_mode == 'window')
	{
		if($mybb->input['go_to'] != 'shoutbox')
		{
			return;
		}
	}
	
	$lang->load('shoutbox');
	
	if($mybb->usergroup['can_view_shoutbox'] != 1)
	{
		if($view_mode == 'index')
		{
			return;
		}
		else
		{
			shoutbox_error($lang->error_no_permission);
		}
	}
	
	if($mybb->input['action'] == 'toggle_refresh' && $mybb->settings['sb_refresh_time'] > 0)
	{
		if($_COOKIE['sb_refresh_disable'] == '1')
		{
			my_setcookie('sb_refresh_disable', '0');
			$auto_refresh_toggle_action = $lang->disable; // provide option to disable at bottom of page
		}
		else
		{
			my_setcookie('sb_refresh_disable', '1');
			$auto_refresh_toggle_action = $lang->enable; // provide option to enable at bottom of page
		}
	}
	
	if($mybb->input['action'] == 'delete')
	{
		if(intval($mybb->input['sid']))
		{
			$sid = intval($mybb->input['sid']);
		}
		else
		{
			shoutbox_error($lang->error_invalid_shout);
		}
		
		$query = $db->simple_select('shouts', 'sid, uid', "sid='{$sid}'");
		$shout = $db->fetch_array($query);
		
		if(($mybb->user['uid'] != $shout['uid'] || $mybb->usergroup['can_delete_own_shouts'] != '1') && $mybb->usergroup['can_moderate_shouts'] != '1')
		{
			shoutbox_error($lang->error_invalid_shout);
		}
		
		if($mybb->request_method == 'post')
		{
			if(!$mybb->input['no'])
			{
				$db->delete_query('shouts', "sid='{$sid}'", 1);
				
				if($mybb->settings['sb_friendly_redirects'] == '1' || $view_mode == 'index')
				{
					shoutbox_redirect($lang->redirect_shout_deleted, $view_mode);
				}
			}
		}
		else
		{
			eval("\$delete_shout = \"".$templates->get('shoutbox_delete_shout')."\";");
			output_page($delete_shout);
			exit;
		}
	}
	
	if($mybb->input['action'] == 'edit')
	{
		if(intval($mybb->input['sid']))
		{
			$sid = intval($mybb->input['sid']);
		}
		else
		{
			shoutbox_error($lang->error_invalid_shout);
		}
		
		$query = $db->simple_select('shouts', 'sid, uid, message', "sid='{$sid}'");
		$shout = $db->fetch_array($query);
		
		if(($mybb->user['uid'] != $shout['uid'] || $mybb->usergroup['can_edit_own_shouts'] != '1') && $mybb->usergroup['can_moderate_shouts'] != '1')
		{
			shoutbox_error($lang->error_invalid_shout);
		}
		
		if($mybb->request_method == 'post')
		{
			if(strlen($mybb->input['message']) > $mybb->settings['sb_max_length'])
			{
				$lang->error_shout_length = sprintf($lang->error_shout_length, $mybb->settings['sb_max_length']);
				shoutbox_error($lang->error_shout_length);
			}
			
			$message = $db->escape_string(trim($mybb->input['message']));
			
			$db->write_query("UPDATE ".TABLE_PREFIX."shouts SET message='{$message}' WHERE sid='{$sid}'");
			
			if($mybb->settings['sb_friendly_redirects'] == '1' || $view_mode == 'index')
			{
				shoutbox_redirect($lang->redirect_shout_edited, $view_mode);
			}
		}
		else
		{
			$message = htmlspecialchars_uni($shout['message']);
			eval("\$edit_shout = \"".$templates->get('shoutbox_edit_shout')."\";");
			output_page($edit_shout);
			exit;
		}
	}
	
	$query = $db->simple_select('shouts', 'COUNT(sid) AS count');
	$total_shouts = $db->fetch_field($query, 'count');
	
	if($mybb->input['action'] == 'add' && $mybb->request_method == 'post')
	{
		if(!empty($mybb->input['message']))
		{
			if($mybb->usergroup['can_post_shouts'] != 1)
			{
				shoutbox_error($lang->error_add_shout);
			}
			
			if($mybb->usergroup['can_bypass_limit'] != 1)
			{
				if($total_shouts >= $mybb->settings['sb_max_consec_shouts'])
				{
					$flood_check = 0;
					
					$options = array(
						'order_by' => 'dateline',
						'limit_start' => $total_shouts - $mybb->settings['sb_max_consec_shouts'],
						'limit' => intval($mybb->settings['sb_max_consec_shouts'])
					);
					
					$query = $db->simple_select('shouts', 'sid, uid', '', $options);
					while($shout = $db->fetch_array($query))
					{
						if($shout['uid'] == $mybb->user['uid'])
						{
							++$flood_check;
						}
					}
					
					if($flood_check >= $mybb->settings['sb_max_consec_shouts'])
					{
						$lang->error_flood = $lang->sprintf($lang->error_flood, $uri);
						shoutbox_error($lang->error_flood);
					}
				}
			}
			
			if(strlen($mybb->input['message']) < $mybb->settings['sb_min_length'])
			{
				$lang->error_shout_too_short = $lang->sprintf($lang->error_shout_too_short, $mybb->settings['sb_min_length'], $uri);
				shoutbox_error($lang->error_shout_too_short);
			}
			
			if(strlen($mybb->input['message']) > $mybb->settings['sb_max_length'])
			{
				$lang->error_shout_too_long = $lang->sprintf($lang->error_shout_too_long, $mybb->settings['sb_max_length'], $uri);
				shoutbox_error($lang->error_shout_too_long);
			}
			
			$new_shout = array(
				'uid'		=> $mybb->user['uid'],
				'message'	=> $db->escape_string(trim($mybb->input['message'])),
				'dateline'	=> TIME_NOW,
				'ipaddress'	=> get_ip()
			);
			
			$db->insert_query('shouts', $new_shout);
			++$total_shouts;
		}
	}
	
	if(!$total_shouts)
	{
		$multipage = '';
		eval("\$shouts = \"".$templates->get("shoutbox_error_no_shouts")."\";");
	}
	else
	{
		$total_pages = ceil($total_shouts / $shouts_per_page);
		
		if(intval($mybb->input['page']))
		{
			$page = intval($mybb->input['page']);
		}
		else
		{
			if($mybb->settings['sb_sort_order'] == 'dsc')
			{
				$page = $total_pages;
			}
			else
			{
				$page = 1;
			}
		}
		
		if($page == $total_pages)
		{
			$start = 0;
			$limit = $total_shouts - (($total_pages - 1) * $shouts_per_page);
		}
		else
		{
			$limit = $shouts_per_page;
			
			if($page == 1)
			{
				$start = $total_shouts - $limit;
			}
			else
			{
				$start = $total_shouts - ($limit * $page);
			}
		}
		
		if($view_mode != 'window')
		{
			$multipage_links = multipage($total_shouts, $shouts_per_page, $page, 'index.php');
		}
		else
		{
			$multipage_links = multipage($total_shouts, $shouts_per_page, $page, 'index.php?go_to=shoutbox&amp;view_mode=window');
		}
		
		require_once MYBB_ROOT.'inc/class_parser.php';
		$parser = new postParser;
		
		if($mybb->settings['sb_sort_order'] == 'dsc')
		{
			$sort_dir = 'DESC';
		}
		else
		{
			$sort_dir = 'ASC';
		}
		
		$query = $db->write_query("
			SELECT s.*, u.username, u.usergroup, u.displaygroup
			FROM ".TABLE_PREFIX."shouts s
			LEFT JOIN ".TABLE_PREFIX."users u
			ON (u.uid=s.uid)
			ORDER BY s.dateline {$sort_dir}
			LIMIT {$start}, {$limit}
		");
		
		$bgcolor = '';
		
		if($total_pages > 1 && $view_mode != 'index')
		{
			$bgcolor = alt_trow();
			eval("\$multipage_top = \"".$templates->get('shoutbox_multipage_links')."\";");
		}
		
		while($shout = $db->fetch_array($query))
		{
			$mecheck = explode(' ', $shout['message']);
			if($mecheck[0] == '/me' || $mecheck[0] == '/slap')
			{
				$username = '';
			}
			else
			{
				if($shout['uid'] > 0)
				{
					$username = format_name($shout['username'], $shout['usergroup'], $shout['displaygroup']);
					$username = '&lt;'.build_profile_link($username, $shout['uid'], 'new').'&gt;';
				}
				else
				{
					$username = '&lt;'.$lang->guest.'&gt;';
				}
			}
			
			$parser_options = array(
				'allow_html'	=> $mybb->settings['sb_allow_html'],
				'allow_mycode'	=> $mybb->settings['sb_allow_mycode'],
				'allow_smilies'	=> $mybb->settings['sb_allow_smilies'],
				'allow_imgcode'	=> $mybb->settings['sb_allow_imgcode'],
				'me_username'	=> $shout['username']
			);
			
			$shout['message'] = $parser->parse_message($shout['message'], $parser_options);
			
			$bgcolor = alt_trow();
			
			$shout_date = my_date($mybb->settings['dateformat'], $shout['dateline']);
			$shout_time = my_date($mybb->settings['timeformat'], $shout['dateline']);
			
			$shout['ip'] = '';
			if($mybb->usergroup['can_moderate_shouts'] == '1')
			{
				$shout['ip'] = $lang->sprintf($lang->shout_hover_ip, $shout['ipaddress']);
			}
			
			$shout_hover = $lang->sprintf($lang->shout_hover, $shout_date, $shout_time, $shout['ip']);
			
			$options = '';
			if((($mybb->user['uid'] == $shout['uid'] && $mybb->usergroup['can_edit_own_shouts'] == '1') || ($mybb->usergroup['can_moderate_shouts'] == '1')) && $mybb->user['usergroup'] != '1')
			{
				$options .= ' [&nbsp;<a href="index.php?go_to=shoutbox&amp;view_mode='.$view_mode.'&amp;action=edit&amp;sid='.$shout['sid'].'">'.$lang->edit.'</a>&nbsp;]';
			}
			
			if((($mybb->user['uid'] == $shout['uid'] && $mybb->usergroup['can_delete_own_shouts'] == '1') || ($mybb->usergroup['can_moderate_shouts'] == '1')) && $mybb->user['usergroup'] != '1')
			{
				$options .= '&nbsp;[&nbsp;<a href="index.php?go_to=shoutbox&amp;view_mode='.$view_mode.'&amp;action=delete&amp;sid='.$shout['sid'].'">'.$lang->delete.'</a>&nbsp;]';	
			}
			
			eval("\$shouts .= \"".$templates->get('shoutbox_shout')."\";");
		}
		
		if($total_pages > 1)
		{
			$bgcolor = alt_trow();
			eval("\$multipage_bottom = \"".$templates->get('shoutbox_multipage_links')."\";");
		}
	}
	
	if(!$auto_refresh_toggle_action)
	{
		if($_COOKIE['sb_refresh_disable'] == '1')
		{
			$auto_refresh_toggle_action = $lang->enable;
		}
		else
		{
			$auto_refresh_toggle_action = $lang->disable;
		}
	}
	
	$toggle_refresh_link = '';
	if($mybb->settings['sb_refresh_time'] > 0)
	{
		$lang->auto_refresh = $lang->sprintf($lang->auto_refresh, $auto_refresh_toggle_action);
		eval("\$toggle_refresh_link = \"".$templates->get('shoutbox_toggle_refresh_link')."\";");
	}
	
	if($mybb->usergroup['can_post_shouts'] == '1')
	{
		eval("\$add_shout = \"".$templates->get('shoutbox_add_shout')."\";");
	}
	
	eval("\$shoutbox_table = \"".$templates->get('shoutbox_table')."\";");
	
	if($view_mode == 'index')
	{
		eval("\$shoutbox = \"".$templates->get('shoutbox_index')."\";");
	}
	else
	{
		eval("\$shoutbox = \"".$templates->get('shoutbox')."\";");
		output_page($shoutbox);
		exit;
	}
}

function shoutbox_error($message)
{
	global $mybb, $theme, $templates, $headerinclude;
	
	eval("\$error = \"".$templates->get('shoutbox_error')."\";");
	output_page($error);
	exit;
}

function shoutbox_redirect($message, $view_mode)
{
	global $lang, $mybb;
	
	if($mybb->settings['sb_friendly_redirects'] == '1')
	{
		redirect('index.php?go_to=shoutbox&view_mode='.$view_mode, $message, $lang->shoutbox);
	}
	else
	{
		if($view_mode != 'index')
		{
			header('Location: index.php?go_to=shoutbox&view_mode=window');
		}
		else
		{
			header('Location: index.php#shoutbox');
		}
	}
}

function shoutbox_get_data()
{
	global $mybb;
	
	if($mybb->input['go_to'] == 'shoutbox' && $mybb->input['action'] == 'get_shouts')
	{
		// get shout data and return as html here (echo?)
		
		echo '<p>show all the shouts for this page here</p>'; // testing
	}
}
?>