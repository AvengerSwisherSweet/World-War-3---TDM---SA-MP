<?php
/**
 * Shoutbox Plugin for MyBB
 * Copyright � 2007 MyBB Mods
 *
 * By: Musicalmidget
 * Website: http://mods.mybboard.net/
 */

/* YOU MAY TRANSLATE THIS FILE FOR YOUR OWN PERSONAL USE,
 * AND DISTRIBUTE IT AS YOU WISH.  HOWEVER, YOU MAY NOT
 * DISTRIBUTE ANY FILES FROM THIS PLUGIN OTHER THAN TRANSLATED
 * LANGUAGE FILES WITHOUT THE PRIOR CONSENT OF THE AUTHOR.
 * SEE THE INCLUDED README.TXT FOR FURTHER DETAILS.
 */

$l['shoutbox'] = 'Shoutbox';
$l['shoutbox_description'] = 'Add a fully integrated shoutbox to your MyBB installation.';

$l['setting_group_shoutbox'] = 'Shoutbox Options';
$l['setting_group_shoutbox_desc'] = 'Settings related to the shoutbox plugin.';

$l['setting_sb_shouts_per_page'] = 'Shouts Per Page';
$l['setting_sb_refresh_time'] = 'Auto Refresh Time';
$l['setting_sb_max_consec_shouts'] = 'Maximum Consecutive Shouts';
$l['setting_sb_max_length'] = 'Maximum Shout Length';
$l['setting_sb_min_length'] = 'Minimum Shout Length';
$l['setting_sb_allow_html'] = 'Allow HTML';
$l['setting_sb_allow_mycode'] = 'Allow MyCode';
$l['setting_sb_allow_smilies'] = 'Allow Smilies';
$l['setting_sb_allow_imgcode'] = 'Allow [img] Code';
$l['setting_sb_display_mode'] = 'Display Mode';
$l['setting_sb_index_shouts'] = 'Shouts Per Page on Index';
$l['setting_sb_sort_order'] = 'Shout Sorting Order';
$l['setting_sb_friendly_redirects'] = 'Show Friendly Redirect Pages';
$l['setting_sb_width'] = 'Shoutbox Width';
$l['setting_sb_height'] = 'Shoutbox Height';
$l['setting_sb_shouts_per_page_desc'] = 'The number of shouts to show on each shoutbox page.';
$l['setting_sb_refresh_time_desc'] = 'The number of seconds between auto-refreshes in the shoutbox.<br />Set the time to <strong>0</strong> to disable auto-refresh.';
$l['setting_sb_max_consec_shouts_desc'] = 'The maximum number of consecutive shouts that a user may post before another user shouts.';
$l['setting_sb_max_length_desc'] = 'The maximum allowed length of shouts.  This setting applies to <strong>all</strong> users.';
$l['setting_sb_min_length_desc'] = 'The minimum allowed length of shouts.  This setting applies to <strong>all</strong> users.';
$l['setting_sb_allow_html_desc'] = 'Would you like to allow users to post HTML code into the shoutbox?  <strong>Note:</strong> Please ensure that you are aware of the risks before enabling this setting.';
$l['setting_sb_allow_mycode_desc'] = 'Would you like to allow the use of MyCode in the shoutbox?';
$l['setting_sb_allow_smilies_desc'] = 'Would you like to allow the use of smilies in the shoutbox?';
$l['setting_sb_allow_imgcode_desc'] = 'Would you like to allow users to post images in the shoutbox?';
$l['setting_sb_display_mode_desc'] = 'Please select where you would like the shoutbox to be displayed.';
$l['setting_sb_index_shouts_desc'] = 'The number of shouts to show on each shoutbox page when the shoutbox is displayed on the index page.';
$l['setting_sb_sort_order_desc'] = 'The order in which shouts should be sorted.';
$l['setting_sb_friendly_redirects_desc'] = 'Would you like to show friendly redirect pages in the shoutbox?';
$l['setting_sb_width_desc'] = 'The width of the shoutbox popup window.';
$l['setting_sb_height_desc'] = 'The height of the shoutbox popup window.';

$l['setting_sb_display_mode_window'] = 'Window Only';
$l['setting_sb_display_mode_index'] = 'Index Only';
$l['setting_sb_display_mode_both'] = 'Both Window and Index';
$l['setting_sb_sort_order_asc'] = 'Ascending';
$l['setting_sb_sort_order_dsc'] = 'Descending';

$l['can_view_shoutbox'] = 'Can view shoutbox?';
$l['can_post_shouts'] = 'Can post shouts?';
$l['can_edit_own_shouts'] = 'Can edit own shouts?';
$l['can_delete_own_shouts'] = 'Can delete own shouts?';
$l['can_moderate_shouts'] = 'Can moderate shouts?';
$l['can_bypass_limit'] = 'Can bypass consecutive shout limit?';

$l['can_prune_shoutbox'] = 'Can prune shoutbox?';

$l['shoutbox_pruning'] = 'Shoutbox Pruning';
$l['shoutbox_pruning_description'] = 'Here you can delete all shouts which are older than a limit you specify.';
$l['date_range'] = 'Date Range:';
$l['older_than'] = 'Older than';
$l['days'] = 'days';
$l['prune_shouts'] = 'Prune Shouts';

$l['success_pruned_shouts'] = 'The shoutbox has been pruned successfully.<br />{1} shouts were deleted.';
?>